<?php

return [
    'widgets' => [
        'account' => [
            'editDetails'      => 'Edit Details',
            'logout'           => 'Logout',
            'availableCredits' => 'Available Credits',
            'commisionBalance' => 'Commision Balance',
            'overdueInvoices'  => 'Overdue Invoices',
            'unpaidInvoices'   => 'Unpaid Invoices',
            'payAllInvoices'   => 'Pay all invoices',
        ]
    ]
];
