<?php

namespace RSThemes\Controller;

use Smarty;
use RSThemes\Helpers\Flash;
use RSThemes\Service\Util;
use RSThemes\Service\URL;
use RSThemes\View\ViewHelper;
use RSThemes\Helpers\RSThemes;

abstract class AbstractController {

    /** @var \Smarty */
    protected $smarty;

    /** @var  string */
    protected $template;

    /** @var string */
    protected $templateType = 'clientarea';

    /** @var  array */
    protected $variables;

    /** @var  array */
    protected $config;

    /** @var string */
    protected $controllerType = 'Client';

    /** @var string */
    protected $controlerName = 'Main';

    /** @var string */
    protected $fullControlerName = 'Main';

    /** @var string */
    protected $actionName = 'index';

    /** @var  string */
    protected $fullActionName;

    /** @var  string */
    protected $extensionName = FALSE;

    /**
     * @param array $params
     * @return mixed
     */
    public static function render($params = []) {
        $class = get_called_class();

        return new $class($params);
    }

    /**
     * AbstractController constructor.
     */
    public function __construct() {
        $this->smarty = new Smarty();
        $this->smarty->caching = 0;
        $configFilePath = ROOTDIR . DS . 'configuration.php';
        if (file_exists($configFilePath)) {
            include $configFilePath;
            if (isset($templates_compiledir) && strlen($templates_compiledir) > 0) {
                if (trim($templates_compiledir, '/') == 'templates_c') {
                    $templates_compiledir = ROOTDIR . DS . $templates_compiledir . DS;
                }
                $this->smarty->compile_dir = $templates_compiledir;
            }
        }
        $this->smarty = RSThemes::Instance()->addSmartyVariables($this->smarty);
        $this->config = require RSTHEMES_DIR . DS . 'resources' . DS . 'config' . DS . 'config.php';
    }

    /**
     * Render adminarea
     */
    public function adminArea() {
        $this->templateType = 'adminarea';
        $this->controllerType = 'Admin';
        try {
            $this->setAction();
            $this->setTemplate();
        } catch (\Throwable $ex) {
            Flash::setFlashMessage('danger', $ex->getMessage());
            self::redirect((new ViewHelper())->url('Templates@index'));
        }

        return $this->renderTemplate();
    }

    /**
     * Set file template path and check whether it is actually exists
     *
     * @throws \Exception
     */
    protected function setTemplate() {
        if (!$this->extensionName) {
            $this->template = $this->templateType . DS . strtolower($this->controlerName) . DS . strtolower($this->actionName) . '.tpl';
            if (!file_exists(RSTHEMES_DIR . DS . 'views' . DS . $this->template)) {
                throw new \Exception('Template file ' . $this->template . ' not found!');
            }
        } else {
            $this->template = $this->templateType . DS . strtolower($this->extensionName) . '.tpl';
        }

    }

    /**
     * Setting controller and action names from url
     *
     * @throws \Exception
     */
    protected function setAction() {
        if (isset($_GET['controller'])) {
            $this->controlerName = filter_input(INPUT_GET, 'controller');
        }
        if (isset($_GET['extension'])) {
            $this->extensionName = filter_input(INPUT_GET, 'extension');
        }
        $this->fullControlerName = 'RSThemes\\Controller\\' . $this->controllerType . '\\' . $this->controlerName . 'Controller';
        if (!class_exists($this->fullControlerName)) {
            throw new \Exception('Controller not found! - ' . $this->fullControlerName);
        }
        $controller = new $this->fullControlerName();
        if (isset($_GET['action'])) {
            $this->actionName = filter_input(INPUT_GET, 'action');
        }
        $this->fullActionName = $this->actionName . 'Action';
        if (!method_exists($controller, $this->fullActionName)) {
            throw new \Exception('Page does not exist!');
        }

        $this->variables = $controller->{$this->fullActionName}();
    }

    /**
     * Render Smarty template with passed previously params
     */
    protected function renderTemplate() {
        $this->appendCommonParams();
        $this->smarty->template_dir = RSTHEMES_DIR . DS . 'views' . DS;
        foreach ($this->variables as $key => $value) {
            $this->smarty->assign($key, $value);
        }
        if (isset($this->variables['render'])) {
            $name = basename($this->template);
            $this->template = str_replace($name, $this->variables['render'] . '.tpl', $this->template);
        }

        if (isset($this->variables['onlyRender'])) {
            return $this->display();
        }

        return $this->smarty->display($this->template);
    }

    /**
     * Process redirection command
     *
     * @param string $url
     */
    public static function redirect($url = '') {
        header("Location: " . $url);
        die();
    }

    /**
     * Set common params in order to send them to all rendered templates
     */
    private function appendCommonParams() {
        $this->variables['flash'] = Flash::getFlashMessages();
        $this->variables['addonURL'] = URL::generateWithParams(['module' => 'RSThemes'], null, false);
        $this->variables['helper'] = new ViewHelper();
        $this->variables['whmcsURL'] = Util::getSystemUrl();
    }

    /**
     * @param array $params
     */
    protected function jsonResponse(array $params = []) {
        ob_clean();
        echo json_encode($params);
        exit();
    }

    public function display() {
        ob_clean();
        echo $this->smarty->display($this->template);
        exit();
    }

}
