<?php

return [
    'display_name' => 'Boxes',
    'description'  => 'Boxes - Support Ticket Departments',
    'preview'      => 'thumb.png',
    'variables' => [
    ]
];