<?php

return [
    'display_name' => 'Client Register',
    'description'  => 'Client Register description',
    'group'        => 'Client Area',
    'preview'      => '',
    'variables'    => [

    ],
];
