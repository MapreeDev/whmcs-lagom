<?php

return [
    'display_name' => 'Homepage',
    'description'  => 'Homepage',
    'group'        => 'Client Area',
    'preview'      => '',
    'variables'    => [

    ],
];
