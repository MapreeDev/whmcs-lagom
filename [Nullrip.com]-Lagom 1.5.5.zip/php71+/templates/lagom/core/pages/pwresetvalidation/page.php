<?php

return [
    'display_name' => 'Password Reset Validation',
    'description'  => 'Password Reset Validation',
    'preview'      => '',
    'group'        => 'Client Area',
    'variables'    => [

    ],
];