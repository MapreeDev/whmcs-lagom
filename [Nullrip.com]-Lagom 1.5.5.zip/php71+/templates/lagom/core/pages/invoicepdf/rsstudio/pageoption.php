<?php

return [
    'display_name' => 'RS Studio',
    'description'  => '',
    'preview'      => 'thumb.png',
    'variables' => []
];