<?php

return [
    'display_name' => 'Invoice PDF',
    'description'  => '',
    'group'        => 'Client Area',
    'variables'    => [

    ],
];
