<?php

return [
    'display_name' => 'User Invite Accept',
    'description'  => 'User Invite Accept',
    'group'        => 'Client Area',
    'preview'      => '',
    'variables'    => [

    ],
];
