<?php

return [
    'display_name' => 'Two Factor Challenge',
    'description'  => 'Two Factor Challenge',
    'group'        => 'Client Area',
    'preview'      => '',
    'variables'    => [

    ],
];
