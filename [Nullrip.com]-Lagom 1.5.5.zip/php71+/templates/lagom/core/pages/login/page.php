<?php

return [
    'display_name' => 'Login',
    'description'  => 'Login Page',
    'group'        => 'Client Area',
    'preview'      => '',
    'variables'    => [

    ],
];
