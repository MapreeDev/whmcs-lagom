<?php

return [
    'display_name' => 'Login Social',
    'description'  => '',
    'preview'      => 'thumb.png',
    'variables' => [
        'isFullPage' => false,
    ]
];