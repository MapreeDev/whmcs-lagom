<?php

return [
    'display_name' => 'Left Wide',
    'version'      => '1.4.0',
    'preview'      => 'thumb.png',
	'order' => 4,
    "variables" => [
        'bodyClass' =>  'lagom-layout-left-wide',
        'type'      =>  'navbar-left',
        'modules' => [
            //'vultr',
        ],
    ]
];

