<?php

return [
    'display_name' => 'Condensed',
    'type' => 'top',
    'theme_layout' => 'Condensed',
    'template_layout' => 'condensed',
    'preview'      => 'thumb.png',
	'order' => 2,
    "variables" => [
        'bodyClass' =>  'lagom-layout-top lagom-layout-condensed',
        'type'      =>  'condensed',
    ]
];
