<?php

return [
    'displayName'  => 'Default',
    'preview'      => 'thumb.png',
	'order' => 1,
    "variables" => [
        'footerClass' =>  '',
        'type'      =>  'default',
    ]
];