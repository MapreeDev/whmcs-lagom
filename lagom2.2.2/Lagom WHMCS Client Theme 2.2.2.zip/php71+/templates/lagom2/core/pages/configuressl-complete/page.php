<?php

return [
    'display_name' => 'Configure SSL - complete',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => false,
    'variables'    => [

    ],
];