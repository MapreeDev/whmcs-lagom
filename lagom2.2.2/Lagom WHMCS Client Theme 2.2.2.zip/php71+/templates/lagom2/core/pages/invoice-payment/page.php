<?php

return [
    'display_name' => 'Invoice Payment',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => false,
    'variables'    => [

    ],
];