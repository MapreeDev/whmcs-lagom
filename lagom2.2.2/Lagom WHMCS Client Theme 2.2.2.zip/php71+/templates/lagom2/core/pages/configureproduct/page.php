<?php

return [
    'display_name' => 'Configure Products',
    'group'        => 'Order',
    'type' => 'order-process',
    'listDisplay' => false,
    'variables'    => [

    ],
];