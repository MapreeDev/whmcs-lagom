<?php

return [
    'display_name' => 'Knowledgebase Article',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'cms_type' => 'website',
    'listDisplay' => false,
    'hideSeoSettings' => true,
    'variables'    => [

    ],
];