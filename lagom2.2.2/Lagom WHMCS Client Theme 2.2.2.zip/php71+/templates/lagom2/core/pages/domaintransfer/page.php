<?php

return [
    'display_name' => 'Domain Transfer',
    'group'        => 'Order',
    'type' => 'order-process',
    'listDisplay' => true,
    'variables'    => [

    ],
];