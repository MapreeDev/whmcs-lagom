<?php

return [
    'display_name' => 'Domain Email Forwarding',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'variables'    => [

    ],
    'listDisplay' => false,
    
];