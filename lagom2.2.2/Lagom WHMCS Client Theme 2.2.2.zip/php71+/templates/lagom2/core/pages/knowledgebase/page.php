<?php

return [
    'display_name' => 'Knowledgebase',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'cms_type' => 'website',
    'listDisplay' => true,
    'variables'    => [

    ],
];
