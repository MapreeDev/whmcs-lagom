<?php

return [
    'display_name' => 'Forward Page',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => false,
    'variables'    => [

    ],
];