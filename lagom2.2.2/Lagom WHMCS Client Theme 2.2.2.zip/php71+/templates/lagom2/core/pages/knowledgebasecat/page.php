<?php

return [
    'display_name' => 'Knowledgebase Categories',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'cms_type' => 'website',
    'listDisplay' => false,
    'variables'    => [

    ],
];