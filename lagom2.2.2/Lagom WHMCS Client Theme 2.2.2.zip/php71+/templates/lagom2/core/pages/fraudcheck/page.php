<?php

return [
    'display_name' => 'Fraudcheck',
    'group'        => 'Order',
    'type' => 'client-portal',
    'listDisplay' => false,
    'variables'    => [

    ],
];