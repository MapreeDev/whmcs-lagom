<?php

return [
    'display_name' => 'Downloads Denied',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => false,
    'variables'    => [

    ],
];