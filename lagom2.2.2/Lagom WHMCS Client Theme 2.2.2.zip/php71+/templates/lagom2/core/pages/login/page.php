<?php

return [
    'display_name' => 'Login',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'cms_type' => 'website',
    'listDisplay' => true,
    'variables'    => [

    ],
];