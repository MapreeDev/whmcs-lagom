<?php

return [
    'display_name' => 'Domain Renewals',
    'group'        => 'Order',
    'type' => 'order-process',
    'listDisplay' => true,
    'variables'    => [

    ],
];