<?php

return [
    'display_name' => 'Invoice PDF',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => false,
    'hidePageSettings' => true,
    'variables'    => [

    ],
];