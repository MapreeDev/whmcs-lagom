<?php

return [
    'display_name' => 'Configure SSL - step one',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => false,
    'variables'    => [

    ],
];