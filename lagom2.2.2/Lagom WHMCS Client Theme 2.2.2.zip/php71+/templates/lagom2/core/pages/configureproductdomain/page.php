<?php

return [
    'display_name' => 'Configure Product Domain',
    'group'        => 'Order',
    'type' => 'order-process',
    'listDisplay' => false,
    'variables'    => [

    ],
];