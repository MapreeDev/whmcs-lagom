<?php

return [
    'display_name' => 'Domain Register NS',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => false,
    'variables'    => [

    ],
];