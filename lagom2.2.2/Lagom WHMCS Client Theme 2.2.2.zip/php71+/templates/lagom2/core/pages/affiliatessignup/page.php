<?php

return [
    'display_name' => 'Affiliates Signup',
    'group'        => 'Client Area',
    'type' => 'website',
    'cms_type' => 'website',
    'listDisplay' => true,
    'variables'    => [

    ],
];