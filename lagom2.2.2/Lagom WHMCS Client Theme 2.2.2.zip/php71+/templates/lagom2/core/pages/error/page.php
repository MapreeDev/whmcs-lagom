<?php

return [
    'display_name' => 'Error',
    'group'        => 'Order',
    'type' => 'client-portal',
    'listDisplay' => false,
    'variables'    => [

    ],
];