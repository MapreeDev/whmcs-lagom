<?php

return [
    'display_name' => 'Complete',
    'group'        => 'Order',
    'type' => 'order-process',
    'listDisplay' => false,
    'variables'    => [

    ],
];