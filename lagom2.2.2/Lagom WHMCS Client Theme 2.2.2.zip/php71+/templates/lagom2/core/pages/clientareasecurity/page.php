<?php

return [
    'display_name' => 'Security',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => true,
    'variables'    => [

    ],
];