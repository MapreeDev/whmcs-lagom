<?php

return [
    'display_name' => 'Affiliates',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => true,
    'variables'    => [

    ],
];