<?php

return [
    'display_name' => 'Client Register',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'cms_type' => 'website',
    'listDisplay' => true,
    'variables'    => [

    ],
];