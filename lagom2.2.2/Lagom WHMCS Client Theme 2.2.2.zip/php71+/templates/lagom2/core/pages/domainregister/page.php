<?php

return [
    'display_name' => 'Domain Register',
    'group'        => 'Order',
    'type' => 'order-process',
    'listDisplay' => true,
    'variables'    => [

    ],
];