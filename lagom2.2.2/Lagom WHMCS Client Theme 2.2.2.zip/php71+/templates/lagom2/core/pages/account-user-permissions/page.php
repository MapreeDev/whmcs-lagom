<?php

return [
    'display_name' => 'Account User Permissions',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => true,
    'variables'    => [

    ],
];