<?php

return [
    'display_name' => 'Configure SSL - step two',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => false,
    'variables'    => [

    ],
];