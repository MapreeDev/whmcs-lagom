<?php

return [
    'display_name' => 'Downloads Categories',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => true,
    'variables'    => [

    ],
];