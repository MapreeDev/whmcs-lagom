<?php

return [
    'display_name' => 'Quotes',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => true,
    'variables'    => [

    ],
];