<?php

return [
    'display_name' => 'Domain Get EPP',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => false,
    'variables'    => [

    ],
];