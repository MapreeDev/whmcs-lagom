<?php

return [
    'display_name' => 'Homepage',
    'group'        => 'Client Area',
    'type' => 'website',
    'listDisplay' => true,
    'variables'    => [

    ],
];