<?php

return [
    'display_name' => 'Default',
    'preview'      => 'thumb.png'
];