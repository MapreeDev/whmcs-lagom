<?php

return [
    'display_name' => 'Account Contacts Manage',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => true,
    'variables'    => [

    ],
];
