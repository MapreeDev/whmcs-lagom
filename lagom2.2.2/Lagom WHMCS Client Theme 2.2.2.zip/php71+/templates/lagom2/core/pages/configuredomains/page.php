<?php

return [
    'display_name' => 'Configure Domains',
    'group'        => 'Order',
    'type' => 'order-process',
    'listDisplay' => false,
    'variables'    => [

    ],
];